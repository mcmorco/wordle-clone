"""
Legacy Python.NET loader for backwards compatibility
"""

from pythonnet import load
load()
